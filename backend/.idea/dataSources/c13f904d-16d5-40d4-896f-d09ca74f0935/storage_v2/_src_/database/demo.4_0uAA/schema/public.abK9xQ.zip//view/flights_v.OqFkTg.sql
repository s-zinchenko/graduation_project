create view flights_v
            (flight_id, flight_no, scheduled_departure, scheduled_departure_local, scheduled_arrival,
             scheduled_arrival_local, scheduled_duration, departure_airport, departure_airport_name, departure_city,
             arrival_airport, arrival_airport_name, arrival_city, status, aircraft_code, actual_departure,
             actual_departure_local, actual_arrival, actual_arrival_local, actual_duration)
as
SELECT f.flight_id,
       f.flight_no,
       f.scheduled_departure,
       timezone(dep.timezone, f.scheduled_departure) AS scheduled_departure_local,
       f.scheduled_arrival,
       timezone(arr.timezone, f.scheduled_arrival)   AS scheduled_arrival_local,
       f.scheduled_arrival - f.scheduled_departure   AS scheduled_duration,
       f.departure_airport,
       dep.airport_name                              AS departure_airport_name,
       dep.city                                      AS departure_city,
       f.arrival_airport,
       arr.airport_name                              AS arrival_airport_name,
       arr.city                                      AS arrival_city,
       f.status,
       f.aircraft_code,
       f.actual_departure,
       timezone(dep.timezone, f.actual_departure)    AS actual_departure_local,
       f.actual_arrival,
       timezone(arr.timezone, f.actual_arrival)      AS actual_arrival_local,
       f.actual_arrival - f.actual_departure         AS actual_duration
FROM flights f,
     airports dep,
     airports arr
WHERE f.departure_airport = dep.airport_code
  AND f.arrival_airport = arr.airport_code;

comment on view flights_v is 'Рейсы';

comment on column flights_v.flight_id is 'Идентификатор рейса';

comment on column flights_v.flight_no is 'Номер рейса';

comment on column flights_v.scheduled_departure is 'Время вылета по расписанию';

comment on column flights_v.scheduled_departure_local is 'Время вылета по расписанию, местное время в пункте отправления';

comment on column flights_v.scheduled_arrival is 'Время прилёта по расписанию';

comment on column flights_v.scheduled_arrival_local is 'Время прилёта по расписанию, местное время в пункте прибытия';

comment on column flights_v.scheduled_duration is 'Планируемая продолжительность полета';

comment on column flights_v.departure_airport is 'Код аэропорта отправления';

comment on column flights_v.departure_airport_name is 'Название аэропорта отправления';

comment on column flights_v.departure_city is 'Город отправления';

comment on column flights_v.arrival_airport is 'Код аэропорта прибытия';

comment on column flights_v.arrival_airport_name is 'Название аэропорта прибытия';

comment on column flights_v.arrival_city is 'Город прибытия';

comment on column flights_v.status is 'Статус рейса';

comment on column flights_v.aircraft_code is 'Код самолета, IATA';

comment on column flights_v.actual_departure is 'Фактическое время вылета';

comment on column flights_v.actual_departure_local is 'Фактическое время вылета, местное время в пункте отправления';

comment on column flights_v.actual_arrival is 'Фактическое время прилёта';

comment on column flights_v.actual_arrival_local is 'Фактическое время прилёта, местное время в пункте прибытия';

comment on column flights_v.actual_duration is 'Фактическая продолжительность полета';

alter table flights_v
    owner to postgres;

