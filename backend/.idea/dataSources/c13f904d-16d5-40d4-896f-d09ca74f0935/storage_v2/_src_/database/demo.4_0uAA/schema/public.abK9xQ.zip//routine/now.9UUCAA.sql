create function now() returns timestamp with time zone
    immutable
    cost 0
    language sql
as
$$
SELECT '2016-10-13 17:00:00'::TIMESTAMP AT TIME ZONE 'Europe/Moscow';
$$;

comment on function now() is 'Момент времени, относительно которого сформированы данные';

alter function now() owner to postgres;

